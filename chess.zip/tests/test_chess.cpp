#define CHESS_TESTING
#include "../main.cpp"
#include <cassert>
#include <iostream>
#include <stdexcept>

void test_parse_square() {
    auto a1 = parseSquare("a1");
    assert(a1.first == 7 && a1.second == 0);
    auto h8 = parseSquare("h8");
    assert(h8.first == 0 && h8.second == 7);
    bool thrown = false;
    try { parseSquare("z9"); } catch (const std::invalid_argument&) { thrown = true; }
    assert(thrown);
}

void test_basic_move() {
    ChessGame game;
    game.makeMoveText("e2", "e4");
    assert(game.pieceAt(4, 4).type == PieceType::Pawn);
    assert(game.pieceAt(4, 4).color == Color::White);
    assert(game.turn() == Color::Black);
}

void test_illegal_move() {
    ChessGame game;
    bool thrown = false;
    try { game.makeMoveText("e2", "e5"); } catch (const std::runtime_error&) { thrown = true; }
    assert(thrown);
}

void test_fools_mate() {
    ChessGame game;
    game.makeMoveText("f2", "f3");
    game.makeMoveText("e7", "e5");
    game.makeMoveText("g2", "g4");
    game.makeMoveText("d8", "h4");
    assert(game.isCheckmate(Color::White));
}

void test_promotion() {
    ChessGame game;
    game.loadBoard({
        "....k...",
        "P.......",
        "........",
        "........",
        "........",
        "........",
        "........",
        "....K..."
    }, Color::White);
    game.makeMoveText("a7", "a8", 'q');
    assert(game.pieceAt(0, 0).type == PieceType::Queen);
}

int main() {
    test_parse_square();
    test_basic_move();
    test_illegal_move();
    test_fools_mate();
    test_promotion();
    std::cout << "All tests passed\n";
    return 0;
}
